/*:
 # Functions
 * Callout(說明):
 [Function](glossary://Function), it also can be called a method, or a mathematical F(x). By designing a function and calling it to solve a series of problems.
 \
In Gi’s world, you can connect with Gi’s power through the **function** to help her use her power more correctly and become a rect guardian.

 ## RectPower
 The RectPower function allows Gi to launch the rect, you need to adjust the following parameters :
 * dx：If it is greater than 0, the horizontal component of the direction is to the right, and if it is less than 0, it is to the left.
 * dy：If it is greater than 0, the vertical component of the direction is upward, and less than 0 is downward.
 
 **Target：** Using `RectPower` function, precisely adjust the parameters of  `dx`, `dy`, so that Gi can inject her power into the fading rect.
 
- Example:
RectPower(dx: ``0.4``, dy: ``-0.6``)
The forces are horizontal 0.4 the the right and vertical 0.6 to the down.

 ### The Fading Rect

- Note:
The fading rect has the effect of a gravitational field, and you have to observe the direction of its gravity.
* ▼ : the direction of field is downward.
* ▲ : the direction of field is upward.
 
*/
RectPower(dx: /*#-editable-code*/<#T##dx##Double#>/*#-end-editable-code*/, dy: /*#-editable-code*/<#T##dy##Double#>/*#-end-editable-code*/)

//#-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, RectPower(dx:, dy:))
//#-end-hidden-code
