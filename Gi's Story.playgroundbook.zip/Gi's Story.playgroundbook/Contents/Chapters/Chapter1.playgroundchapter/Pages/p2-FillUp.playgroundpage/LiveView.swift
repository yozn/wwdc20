import PlaygroundSupport
import UIKit
PlaygroundPage.current.liveView = getGameViewController(pageName:"p2")
