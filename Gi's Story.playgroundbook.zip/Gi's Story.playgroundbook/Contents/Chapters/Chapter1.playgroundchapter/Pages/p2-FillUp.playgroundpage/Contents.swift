/*:
 **Challenge** : Using functions continuously
 There are four rects that have lost power. Please help Gi to use her power to recharge the rects.
 
 After using `moveForward` to be near the rect, then use `fillUp` to fill the rect with energy.
 
     moveForward(step: 7)
     fillUp(color: 🟧)
*/
//#-hidden-code
import UIKit
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, moveForward(step:), fillUp(color:))
//#-code-completion(literal, show, color)
//#-editable-code
moveForward(step: 7)
fillUp(color: #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1))
//#-end-editable-code
//#-hidden-code
sendToView(.string("run-p2"))
//#-end-hidden-code

