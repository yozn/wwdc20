import PlaygroundSupport
import SpriteKit
import UIKit

PlaygroundPage.current.liveView = getGameViewController(pageName:"p4")

