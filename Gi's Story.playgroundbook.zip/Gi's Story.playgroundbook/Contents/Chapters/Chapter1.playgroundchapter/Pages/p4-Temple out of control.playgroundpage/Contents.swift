//#-hidden-code
import UIKit
import PlaygroundSupport
let rectColors = [#colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1), #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1), #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)]
let rectColorAnti = [#colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1), #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1)]
var templeColors = [#colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1), #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1), #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)]
var templeIndex = 0
var templeColor:UIColor{
    return rectColors[templeIndex]
}
func fillUp(color:UIColor){
    var arr:[PlaygroundValue] = []
    arr.append(.floatingPoint(Double(color.rgba.red)))
    arr.append(.floatingPoint(Double(color.rgba.green)))
    arr.append(.floatingPoint(Double(color.rgba.blue)))
    arr.append(.floatingPoint(Double(color.rgba.alpha)))
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(.array(arr))
    if color.isEqual(rectColorAnti[templeIndex]){
        templeIndex += 1
    }
}
//#-end-hidden-code
/*:
 # Condition If-else
 * Callout(Introduction):
 [if-else](glossary://if-else) can choose the direction of code execution according to the situation, and you can use your logic to write the code more comprehensively.
 
 When the condition of the `if` is true, then `myFunc` will be executed, otherwise if will not.
 
    if condition {
        myFunc()
    }
 ## The temple out of control
 **Target** : Using `if-else` allows Gi to send the correct rect based on the condition of the temple to avoid disaster!
 - Note:
 Use the attribute scale to counteract the temple’s out-of-control rects.
 \
 `templeColor` can get the current temple’s out-of-control color.
 * blue -> green
 * red -> blue
 * green -> red
 * yellow -> purple
 * purple -> yellow
*/
templeColors = [#colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1), #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1), #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)]
//#-editable-code
if templeColor == #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1) {
    fillUp(color:#colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1))
}else if templeColor == #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1){
    fillUp(color: #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1))
}
RectPower()
//#-end-editable-code
//#-hidden-code
sendToView(.string("run-p4"))
//#-end-hidden-code

