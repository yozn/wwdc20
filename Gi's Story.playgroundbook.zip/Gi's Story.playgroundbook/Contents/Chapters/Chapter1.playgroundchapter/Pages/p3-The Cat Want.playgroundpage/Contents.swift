/*:
 # For-In Loops
 * Callout(Introduction):
 [Loop](glossary://ForLoop) can repeat the execution of code. It is an important and common skill in learning to code.
 \
 In [last page](@previous),  I wonder if you found some repetitive and regular code that can be optimized using loops.
 
 Using the for loop to repeat code like this.
    
    for i in 1 ... 4 {
        Fillup(color: 🟦)
        RectPower()
    }
 
 ## The catWantRects array
 **Target** : The cat has always been a good companion to the Rect Guardian, but it seems a bit lazy. Please help Gi to replenish the cat’s energy!
 `catWantRects` holds the rect the cat wants, takes it out and passes it on to the cat..
 
 - Note:
 `catWantRects[0]` get the orange rect
 \
`catWantRects[1]` get the purple rect
 \
 and so on.
 
* You can also use the `for` loop to get the rects in the array.
-

    for rect in catWantRects{

    }
*/
//#-hidden-code
import UIKit
var catWantRects = [#colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.9662681222, green: 1, blue: 0, alpha: 1), #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1), #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)]
//#-end-hidden-code
catWantRects = [#colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.9662681222, green: 1, blue: 0, alpha: 1), #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1), #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)]
//#-editable-code
fillUp(color: #colorLiteral(red: 0.17647058823529413, green: 0.011764705882352941, blue: 0.5607843137254902, alpha: 1.0))
RectPower()
//#-end-editable-code

//#-hidden-code
//#-code-compltetion(everything, hide)
//#-code-completion(currentmodule, show)
sendToView(.string("run-p3"))
//#-end-hidden-code
