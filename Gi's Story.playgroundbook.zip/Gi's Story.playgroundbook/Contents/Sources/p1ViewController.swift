//
//  MyViewController.swift
//  Book_Sources
//
//  Created by 劉祐炘 on 2020/2/4.
//

import UIKit
import PlaygroundSupport
import AVFoundation

public class p1ViewController: UIViewController, UICollisionBehaviorDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer{
    let storys = [ 
        "",
        "The pretty girl is Gi.",
        "She found a rect which was about to disapper..",
        "for lack of strength, so she wants to help the rect recharge.",
        "Can you help her to launch RectPower accurately ?"
    ]
    var textlabel:UILabel!
    var player:AVQueuePlayer!
    var playLayer:AVPlayerLayer!
    var playSound:AVAudioPlayer!
    var playLoop:AVPlayerLooper!
    var playRectPower:AVPlayer!
    var targetRect:UIView!
    var timer1:Timer!
    var timer2:Timer!
    var count = 1
    var mask:UIView!
    var giRect:UIView!
    var setupPush:[String:CGFloat] = [
        "dx":0.01,
        "dy":-0.5,
        "g":0.3
    ]
    var animator: UIDynamicAnimator!;
    var gravity: UIGravityBehavior!;
    var collision: UICollisionBehavior!;
    var gflag = 1.0
//    func setView(rect:CGRect) {
//        let view = UIView(frame: rect)
//        view.backgroundColor = UIColor(red: 249/255, green: 247/255, blue: 250/255, alpha: 1)
//        self.view = view
//    }
    public override func loadView() {
        let v = UIView(frame: .init(x: 0, y: 0, width: 834, height: 1112))
        view = v
    }
    override public func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        guard let path_stop = Bundle.main.url(forResource: "gi-look-stop", withExtension: "mov") else {
            return debugPrint("no video/gi-look-stop")
        }
        guard let path_loop = Bundle.main.url(forResource: "gi-look-loop", withExtension: "mov") else {
            return debugPrint("no video/gi-look-loop")
        }
        guard let path_rect = Bundle.main.url(forResource: "gi-Rect", withExtension: "mov") else {
            return debugPrint("no giRect.mov")
        }
        guard let music_path = Bundle.main.url(forResource: "puzzle-1", withExtension: "m4a") else {
            return debugPrint("no puzzle-1")
        }
        
        do{
            playSound = try AVAudioPlayer(contentsOf: music_path)
        }catch{
            return debugPrint("puzzle-1 error")
        }
        playSound.numberOfLoops = -1
        playSound.play()
        playSound.volume = 0.15
        
        player = AVQueuePlayer(url: path_stop)
        playLayer = AVPlayerLayer(player: player)
        
        
        playLayer.frame = .init(x: 0, y: 0, width: view.frame.width / 1.5, height: view.frame.height)
       
        view.layer.addSublayer(playLayer)
        player.play()
        
        let playitem = AVPlayerItem(url: path_loop)
        let playqueue = AVQueuePlayer()
        
       
        
        playLoop = AVPlayerLooper(player: playqueue, templateItem: playitem)
        
        NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main, using: {_ in
            self.playLayer.player = playqueue
            playqueue.play()
            
        })
        mask = UIView(frame: CGRect(x: 120, y: view.frame.midY - 20, width: 150, height: 180))
        mask.backgroundColor = .white
        mask.alpha = 0
        view.addSubview(mask!)
        
        playRectPower = AVPlayer(url: path_rect)
        settextLabel()
        setTargetRect()
        
        // Do any additional setup after loading the view.
    }
    
    func runRect(){
        

        animator = UIDynamicAnimator(referenceView: view)
        gravity = UIGravityBehavior(items: [giRect])
        gravity.magnitude = 10 * CGFloat(gflag)
        let pushRect = UIPushBehavior(items: [giRect], mode: .instantaneous)
        let dy = setupPush["dy"]! * -1
        pushRect.pushDirection = CGVector(dx: setupPush["dx"]!, dy: dy)
        pushRect.setTargetOffsetFromCenter(UIOffset(horizontal: 1.1, vertical: -0.1), for: giRect)
        collision = UICollisionBehavior(items: [giRect]);
        collision.collisionDelegate = self;
        collision.translatesReferenceBoundsIntoBoundary = true;
        collision.addBoundary(withIdentifier: "barrier" as NSCopying, for: UIBezierPath(rect: targetRect.frame))
        
        animator.addBehavior(gravity)
        animator.addBehavior(pushRect)
        animator.addBehavior(collision)
        timer2 = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(self.giRect_to_drak), userInfo: nil, repeats: false)
        
    }
    @objc func giRect_to_drak(){
        timer2.invalidate()
        timer2 = nil
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
            self.giRect.backgroundColor = .darkGray
            self.giRect.alpha = 0
        }, completion: nil)
    }
    func prepareGiRect(){
        
        mask.alpha = 1
        playLayer.player = playRectPower
        playRectPower.seek(to: .zero)
        
        playRectPower.play()
        giRect = UIView(frame: CGRect(x: 125, y: view.frame.midY + 155, width: 40, height: 40))
        giRect.backgroundColor = UIColor(red: 220/255, green: 63/255, blue: 104/255, alpha: 0.9)
        view.addSubview(giRect)
        
        UIView.animate(withDuration: 1, delay: 0, options: [.curveEaseIn], animations: {
            self.giRect.center = CGPoint(x: self.giRect.center.x, y: self.giRect.center.y + 20)
            self.giRect.transform = .init(rotationAngle: -20)
            
        },completion: {(res) in
            self.runRect()
        })
       
        
    }
    func settextLabel(){
        textlabel = UILabel(frame: CGRect(x: 20, y: view.frame.midY + 200, width: 500, height: 20))
        textlabel.textColor = .black
        textlabel.text = storys[0]
        view.addSubview(textlabel)
        labeling()
        timer1 = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(self.labeling), userInfo: nil, repeats: true)
        
    }
    @objc func labeling(){
        if count < storys.count{
            textlabel.text = storys[count]
            count += 1
        }else{
            timer1.invalidate()
            timer1 = nil
            textlabel.alpha = 1
            return
        }
        textlabel.alpha = 0
        self.textlabel.fadeIn(completion: {
            (finished: Bool) -> Void in
            self.textlabel.fadeOut()
            
        })
    }
    func setTargetRect(){
        print(self.view.frame)
        let rx = Int.random(in: 50...Int(self.view.frame.size.width / 2))
        let ry = Int.random(in: 50...Int(self.view.frame.size.height))
        let v = UIView(frame: CGRect(x:  rx - 50, y: ry - 50, width: 50, height: 20))
        
        
        let backgroundImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 50, height: 20))
        if Float.random(in: 0...1) > 0.5{
            backgroundImage.image = UIImage(named: "sort-down.png")
            gflag = 1.0
        }else{
            backgroundImage.image = UIImage(named: "sort-up.png")
            gflag = -1.0
        }
        backgroundImage.contentMode =  .scaleAspectFit
        v.insertSubview(backgroundImage, at: 0)
        v.layer.borderWidth = 1
        targetRect = v
        self.view.addSubview(targetRect)
    }
    public func collisionBehavior(_ behavior: UICollisionBehavior, beganContactFor item: UIDynamicItem, withBoundaryIdentifier identifier: NSCopying?, at p: CGPoint) {
        if let _ = identifier as! String?{
//            print("Boundary contact occurred ", istr);
            targetRect.backgroundColor = giRect.backgroundColor
            if targetRect.backgroundColor!.isEqual(UIColor.darkGray){
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["Look the rect's gravity and watch out the deadline of Gi's power"], solution: "")
                return
            }
            PlaygroundPage.current.assessmentStatus = .pass(message: "**Nice!** Let's go to [Next Page](@next) !")
            textlabel.text = "Good Job!"
            giRect.removeFromSuperview()
        }
        
        
        
    }

    public func receive(_ message: PlaygroundValue) {
        setupPush["dx"] = message.cgfloatFromDict(withKey: "dx")
        setupPush["dy"] = message.cgfloatFromDict(withKey: "dy")
        if timer2 == nil{
            prepareGiRect()
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UIView {
    func fadeIn(duration: TimeInterval = 1.0, delay: TimeInterval = 0.0, completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in}) {
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.alpha = 1.0
        }, completion: completion)
    }
    
    func fadeOut(duration: TimeInterval = 2, delay: TimeInterval = 3.0, completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in}) {
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.alpha = 0.0
        }, completion: completion)
    }
}
