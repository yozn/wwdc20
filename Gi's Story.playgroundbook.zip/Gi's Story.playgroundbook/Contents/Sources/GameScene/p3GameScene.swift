//
//  p3GameScene.swift
//  Book_Sources
//
//  Created by 劉祐炘 on 2020/2/16.
//

import Foundation
import SpriteKit
import PlaygroundSupport
class p3GameScene: GameScene {
    var cloud:SKSpriteNode!
    var cat:SKSpriteNode!
    var catActions:[SKAction] = []
    var showCountLabel:SKLabelNode!
    var catWantRect:SKShapeNode!
    var catTargets:[UIColor] = [#colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.9662681222, green: 1, blue: 0, alpha: 1), #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1), #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)]
    var catTargetIndex = 0
    
    override init() {
        super.init()
        view?.isMultipleTouchEnabled = true
        backgroundColor = UIColor(red: 249/255, green: 247/255, blue: 250/255, alpha: 1)
        setBackGround()
        setGi()
        emitter.setScale(0.4)
        cameraNode.setScale(1.06)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("p3 gamescene init error.")
    }
    override func didMove(to view: SKView) {
        super.didMove(to: view)
    }
    func reset(){
        showCountLabel.text = "x5"
        catTargetIndex = 0
        catWantRect.fillColor = catTargets[catTargetIndex]
    }
    func runCode(){
        if isRun == true{
            return
        }
        isRun = true
        reset()
        runSequence.append(SKAction.run {
            self.runSequence.removeAll()
            self.isRun = false
            if self.catTargets.count - self.catTargetIndex != 0{
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["give the cat the correct rect five times"], solution:
                """
                for rect in catWantRects{\n
                    fillUp(color: rect)\n
                    RectPower()\n
                }
                """)
            }else{
                self.catTargetIndex = 0
            }
        })
        gi.run(SKAction.sequence(runSequence))
    }
    func setBackGround(){
        var catCatchFrames:[SKTexture] = []
        for i in 1...19{
            let f = SKTexture(imageNamed: String(format: "cat-catch%04d.png", arguments: [i]))
            catCatchFrames.append(f)
        }
        cat = SKSpriteNode(texture: catCatchFrames[0])
        var catSeeFrames = Array(catCatchFrames[0..<7])
        catSeeFrames.append(contentsOf: catSeeFrames.reversed())
        cat.position = CGPoint(x: frame.midX, y: frame.midY)
        cat.anchorPoint = CGPoint(x: 0.7 ,y: 0.04) // x right when <0
        let cat_r:CGFloat = 0.5
        
        cat.size = CGSize(width: cat.size.width * cat_r, height: cat.size.height * cat_r)
        cat.name = "cat"
        addChild(cat)
        //        cat.physicsBody = SKPhysicsBody(circleOfRadius: cat.size.width / 4)
        //cat.physicsBody?.isDynamic = false
        //        cat.physicsBody?.affectedByGravity = false
        //        cat.physicsBody?.collisionBitMask = 0
        //        cat.physicsBody?.categoryBitMask = 1
        //        cat.physicsBody?.contactTestBitMask = 0
        let catCatchAction = SKAction.animate(with: catCatchFrames, timePerFrame: 0.15, resize: false, restore: true)
        let catJustSeeAction = SKAction.animate(with: catSeeFrames, timePerFrame: 0.15, resize: false, restore: true)
        catActions.append(contentsOf: [catJustSeeAction, catCatchAction])
        
        var cloudFrames:[SKTexture] = []
        for i in 1...5{
            let f = SKTexture(imageNamed: "cloud000\(i).png")
            cloudFrames.append(f)
            
        }
        cloud = SKSpriteNode(texture: cloudFrames[0])
        let cloud_r:CGFloat = 0.6
        cloud.size = CGSize(width: cloud.size.width * cloud_r, height: cloud.size.height * cloud_r)
        cloud.position = CGPoint(x: 115, y: 225)
        cloud.run(SKAction.repeatForever(
            SKAction.animate(with: cloudFrames, timePerFrame: 0.2, resize: false, restore: true)),withKey: "clouding"
        )
        cat.addChild(cloud)
        
        catWantRect = SKShapeNode(rectOf: CGSize(width: 28, height: 28))
        catWantRect.position = CGPoint(x: 13, y: 14)
        catWantRect.fillColor = catTargets[0]
        catWantRect.strokeColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        catWantRect.lineWidth = 2
        let oneRevolution:SKAction = SKAction.rotate(byAngle: CGFloat.pi, duration: 10)
        let repeatRotation:SKAction = SKAction.repeatForever(oneRevolution)
        catWantRect.run(repeatRotation)
        cloud.addChild(catWantRect)
        
        showCountLabel = SKLabelNode(fontNamed: "chalkduster")
        showCountLabel.fontColor = .black
        showCountLabel.text = "x5"
        showCountLabel.fontSize = 12
        showCountLabel.position = CGPoint(x: 55, y: -20)
        cloud.addChild(showCountLabel)
    }
    func setGi(){
        gi.position = CGPoint(x: 340, y: 115)
        let gi_r = CGFloat(0.35)
        gi.size = CGSize(width: gi.size.width * gi_r, height: gi.size.height * gi_r)
        addChild(gi)
        gi.xScale = abs(gi.xScale) * -1.0
    }
    
    func fillup(color:UIColor){
        let addRectAction = SKAction.sequence([
            SKAction.wait(forDuration: 1.1),
            SKAction.run {
                self.addEmitter(node: self.gi, delay: 1, pos: CGPoint(x: 37, y: 55), color: color)
            },
            SKAction.run {
                if let r = self.gi.childNode(withName: "rect"){
                    r.removeFromParent()
                }
                let rect = SKShapeNode(rectOf: CGSize(width: 33, height: 33))
                rect.position = CGPoint(x: 35, y: 45)
                rect.alpha = 0
                rect.name = "rect"
                rect.fillColor = color
                rect.strokeColor = .clear
                rect.run(self.RotatefloatAction(node: rect))
                rect.zPosition = 1
                self.gi.addChild(rect)
                rect.run(SKAction.fadeAlpha(to: 1, duration: 0.5))
            }
        ])
        let group = SKAction.group([giActions[1], addRectAction])
        runSequence.append(group)
    }
    func RectPower(){
        let prepareAction = SKAction.run {
            guard let rect = self.gi.childNode(withName: "rect") as? SKShapeNode else {return}
            let moveDown = SKAction.move(by: CGVector(dx: 0, dy: -30), duration: 0.8)
            let rDown = SKAction.rotate(byAngle: 0.5, duration: 0.8)
            let groupDown = SKAction.group([moveDown, rDown])
            
            let moveUp = SKAction.move(by: CGVector(dx: 110, dy: 300), duration: 2.3)
            let rUp = SKAction.rotate(byAngle: 0.5, duration: 2.3)
            let groupUp = SKAction.group([moveUp, rUp])
            
            let end = SKAction.run {
                self.addEmitter(node: rect, delay: 1, pos: .zero, color: rect.fillColor)
                rect.run(SKAction.fadeAlpha(to: 0, duration: 0.5))
            }
            let rectAction = SKAction.sequence([
                groupDown,
                groupUp,
                end
            ])
            rect.run(rectAction)
        }
        let catCatchAction = SKAction.run {
            self.catCatch()
        }
        let group = SKAction.group([giActions[2], prepareAction, catCatchAction])
        runSequence.append(group)
        runSequence.append(SKAction.wait(forDuration: 1.2))
        runSequence.append(SKAction.run {
            self.gi.texture = self.gi.normalTexture
        })
    }
    func showEmoji(node:SKNode,em:Character) -> SKAction{
        let labelNode = SKLabelNode(text: String(em))
        labelNode.position = .init(x: -40, y: 160)
        labelNode.fontSize = 40
        labelNode.alpha = 0
        let addAction = SKAction.run {
            labelNode.alpha = 1
        }
        let fadeAction = SKAction.fadeOut(withDuration: 0.75)
        let moveAction = SKAction.move(by: .init(dx: 0, dy: 50), duration: 0.75)
        
        let removeAction = SKAction.run{
            labelNode.removeFromParent()
        }
        let waitAction = SKAction.wait(forDuration: 1)
        let groupAction = SKAction.group([fadeAction, moveAction])
        let seqAction = SKAction.sequence([waitAction,addAction,groupAction, removeAction])
        
        let action = SKAction.run {
            node.addChild(labelNode)
            labelNode.run(seqAction)
        }
        
        return action
    }
    func catCatch(){
        var actions:[SKAction] = []
        guard let rect = gi.childNode(withName: "rect") as? SKShapeNode else {return}
        if rect.fillColor.isEqual(catWantRect.fillColor){
            actions.append(SKAction.wait(forDuration: 1.2))
            actions.append(showEmoji(node: cat, em: "😽"))
            actions.append(catActions[1])
            actions.append(SKAction.wait(forDuration: 0.2))
            actions.append(SKAction.run {
                self.catTargetIndex += 1
                let r = self.catTargets.count - self.catTargetIndex
                if r == 0{
                    PlaygroundPage.current.assessmentStatus = .pass(message: "**Excenllent!** you are great [Next Page](@next)")
//
                }else{
                    self.catWantRect.fillColor = self.catTargets[self.catTargetIndex]
                    self.showCountLabel.text = "x\(r)"
                    
                }
                
            })
        }else{
            
            actions.append(SKAction.wait(forDuration: 1.5))
            actions.append(showEmoji(node: cat, em: "😾"))
            actions.append(catActions[0])
        }
        cat.run(SKAction.sequence(actions))
    }
    
}
