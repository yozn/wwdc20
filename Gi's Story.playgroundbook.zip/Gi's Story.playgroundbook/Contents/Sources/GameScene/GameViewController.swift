//
//  GameViewController.swift
//  Book_Sources
//
//  Created by 劉祐炘 on 2020/2/14.
//

//
//  ContentSupport.swift
//  Book_Sources
//
//  Created by 劉祐炘 on 2020/2/4.
//
import PlaygroundSupport
import SpriteKit
import Foundation
import UIKit


public class GameViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer{
    var gameScene:GameScene!
    var sceneView:SKView!
    var runSceneName = ""
    init(scene:GameScene, name:String){
        super.init(nibName: nil, bundle: nil)
        gameScene = scene
        runSceneName = name
    }
    override public func loadView(){
        super.loadView()
        //        sceneView = SKView.init(frame: CGRect(x: 0, y: 0, width: view.frame.width / 2, height: view.frame.height))
        sceneView = SKView.init(frame: CGRect.init(x: 0, y: 0, width: 375, height: 668))
        self.view = sceneView
        
    }
    required init?(coder: NSCoder) {
        fatalError("GameViewController init error!")
    }
    override public func viewDidLoad() {
        super.viewDidLoad()
        //        sceneView.ignoresSiblingOrder = true
        gameScene.scaleMode = .aspectFill
        sceneView.presentScene(gameScene)
        // Do any additional setup after loading the view.
    }
    public func getTempleColor() -> UIColor{
        if let scene = gameScene as? p4GameScene{
            let color = scene.temple.color
            return color
        }
        return .white
    }
    
    
    
    
    public func receive(_ message: PlaygroundValue) {
        switch message {
        case .integer(let x):
            if let p2scene = gameScene as? p2GameScene{
                p2scene.moveForword(step: x)
            }
            break
        case .string(let s):
            if s == "run"{
                gameScene.runCodeSequence()
            }else if s == "run-p2"{
                if let p2scene = gameScene as? p2GameScene{
                    p2scene.runCode()
                }
            }else if s == "RectPower"{
                if runSceneName == "p4"{
                    if let scene = gameScene as? p4GameScene{
                        scene.RectPower()
                    }
                }else if runSceneName == "p3"{
                    if let scene = gameScene as? p3GameScene{
                        scene.RectPower()
                    }
                }
            }else if s == "run-p3"{
                if let scene = gameScene as? p3GameScene{
                    scene.runCode()
                }
            }else if s == "run-p4"{
                if let scene = gameScene as? p4GameScene{
                    scene.runCode()
                }
            }
            break
        case.array(let arr):
            let color = ValueArrToUIColor(value: arr)
            if runSceneName == "p2"{
                if let p2scene = gameScene as? p2GameScene{
                    p2scene.fillUp(color: color)
                }
            }else if runSceneName == "p3"{
                if let p3scene = gameScene as? p3GameScene{
                    p3scene.fillup(color: color)
                }
            }else if runSceneName == "p4"{
                if let p4scene = gameScene as? p4GameScene{
                    p4scene.fillup(color: color)
                }
            }
            
            break
            
        default:
            break
        }
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
