import SpriteKit
class GameScene:SKScene{
    var gi:SKSpriteNode!
    var giActions:[SKAction] = []
    var runSequence:[SKAction] = []
    let emitter = SKEmitterNode(fileNamed: "spark.sks")!
    var steps = 0
    var cameraNode = SKCameraNode()
    var isRun = false
    override init() {
        //        super.init(size: CGSize(width: UIScreen.main.bounds.size.width / 2, height: UIScreen.main.bounds.size.height))
        super.init(size: CGSize(width: 375, height: 668))
        setGiFrames()
        emitter.particleColorBlendFactor = 1
        emitter.particleColorSequence = nil
        emitter.alpha = 0.85
        emitter.setScale(0.3)
        emitter.name = "emitter"
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("GameScene error init.")
    }
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        cameraNode.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(cameraNode)
        camera = cameraNode
    }
    func setGiFrames(){
        
        var giWalkFrames:[SKTexture] = []
        for i in 1 ... 8{
            let f = SKTexture(imageNamed: "walk000\(i).png")
            giWalkFrames.append(f)
        }
        var giFillUpFrames:[SKTexture] = []
        for i in 1 ... 9{
            let f = SKTexture(imageNamed: "fillup000\(i).png")
            giFillUpFrames.append(f)
        }
        var giPowerFrames:[SKTexture] = []
        for i in 1 ... 8{
            let f = SKTexture(imageNamed: "power000\(i).png")
            giPowerFrames.append(f)
        }
        
        let giWalkAction = SKAction.animate(with: giWalkFrames, timePerFrame: 0.2, resize: false, restore: true)
        let giFillUpAction = SKAction.animate(with: giFillUpFrames, timePerFrame: 0.2, resize: false, restore: true)
        let giRectPowerAction = SKAction.animate(with: giPowerFrames, timePerFrame: 0.2, resize: false, restore: false)
        giActions.append(contentsOf: [giWalkAction, giFillUpAction, giRectPowerAction])
        
        gi = SKSpriteNode(texture: giWalkFrames[0])
        gi.normalTexture = gi.texture
    }
    func addEmitter(node:SKNode, delay:TimeInterval, pos:CGPoint, color:UIColor){
        let addEmitter = SKAction.run {
            guard  let emitterToAdd = self.emitter.copy() as? SKEmitterNode else {
                return
            }
            emitterToAdd.particleColor = color
            emitterToAdd.position = pos
            node.addChild(emitterToAdd)
            
        }
        let endEmitter = SKAction.run {
            guard let e = node.childNode(withName: "emitter") as? SKEmitterNode else {
                return
            }
            e.removeFromParent()
        }
        let emitterAction = SKAction.sequence([
            addEmitter,
            SKAction.wait(forDuration: delay),
            endEmitter])
        node.run(emitterAction)
    }
    
    func runCodeSequence(){
        gi.run(SKAction.repeatForever(giActions[0]))
        let end = SKAction.run {
            self.runSequence.removeAll()
            self.gi.removeAllActions()
            self.steps = 0
        }
        runSequence.append(end)
        gi.run(SKAction.sequence(runSequence))
        
    }
    func distance(_ a:CGPoint, _ b:CGPoint) -> CGFloat{
        let dx = a.x - b.x
        let dy = a.y - b.y
        let d = sqrt((dx * dx) + dy * dy)
        return CGFloat(d)
    }
    func average(_ a:CGPoint, _ b:CGPoint) -> CGPoint{
        return CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2)
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touchs = event?.allTouches else {
            return
        }
        
        let arr = Array(touchs)
        guard let p1 = arr.first else {
            return
        }
        let p1_n = p1.location(in: self)
        let p1_p = p1.previousLocation(in: self)
        if arr.count > 1{
            
            let p2_n = arr[1].location(in: self)
            let p2_p = arr[1].previousLocation(in: self)
            
            let oldDistance = distance(p1_p, p2_p)
            let newDistance = distance(p1_n, p2_n)
            let diff = oldDistance / newDistance
            if diff.isNormal && diff != 1{
                let scaleAction = SKAction.scale(by: diff, duration: 0)
                cameraNode.run(scaleAction)
            }
        }
        let translation = CGPoint(x: p1_n.x - p1_p.x, y: p1_n.y - p1_p.y)
        let panAction = SKAction.moveBy(x: -translation.x, y: -translation.y, duration: 0)
        cameraNode.run(panAction)
    }
    func toRadians(angle:Double) -> Double{
        return angle / 180 * Double.pi
    }
    func RotatefloatAction(node:SKNode) -> SKAction{
        let r = SKAction.sequence([
            SKAction.rotate(byAngle: 0.5, duration: 1.6),
            SKAction.rotate(byAngle: -2.5, duration: 1.6),
        ])
        let redis = 7
        let move = SKAction.sequence([
            SKAction.move(by: .init(dx: 0, dy: redis), duration: 0.8),
            SKAction.move(by: .init(dx: redis, dy: 0), duration: 0.8),
            SKAction.move(by: .init(dx: 0, dy: -redis), duration: 0.8),
            SKAction.move(by: .init(dx: -redis, dy: 0), duration: 0.8),
        ])
        let g = SKAction.group([r, move])
        let repeatAction = SKAction.repeatForever(g)
        return repeatAction
    }
}
