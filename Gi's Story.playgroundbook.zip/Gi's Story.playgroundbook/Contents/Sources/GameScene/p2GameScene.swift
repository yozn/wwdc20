//
//  p2GameScene.swift
//  LiveViewTestApp
//
//  Created by 劉祐炘 on 2020/2/15.
//
import PlaygroundSupport
import SpriteKit
import Foundation

class p2GameScene:GameScene{
    let groundPoint = [20, 267, 350, 50] //groundx groundy recty rectSize
    let rect_xPoints = [95, 165, 230,  290]
    var rects:[SKShapeNode] = []
    var backgroundNode = SKSpriteNode(imageNamed: "bk.png")
    var timer:Timer!
    let fireworkSound = SKAction.playSoundFileNamed("firework1.mp3", waitForCompletion: true)
    override init() {
        //        super.init(size: CGSize(width: UIScreen.main.bounds.size.width / 2, height: UIScreen.main.bounds.size.height))
        super.init()
        backgroundColor = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)
        
        
        
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("p2GameScene error init")
    }
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        setBackGround(view: view)
        setGi()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let location = touches.first?.location(in: self){
            addEmitter(node: self, delay: 1, pos: location, color: .init(red: CGFloat.random(in: 0...1), green: CGFloat.random(in: 0...1), blue: CGFloat.random(in: 0...1), alpha: CGFloat.random(in: 0.5...1)))
        }
    }
    func setBackGround(view:SKView){
        for i in 0 ... 3{ //prepare rect
            let rect = SKShapeNode(rectOf: .init(width: groundPoint[3], height: groundPoint[3]))
            rect.position = CGPoint(x: rect_xPoints[i], y: groundPoint[2])
            rect.fillColor = .white
            rect.alpha = 0.85
            rects.append(rect)
            addChild(rect)
        }
        backgroundNode.position = CGPoint(x: view.frame.midX, y: view.frame.midY)
        backgroundNode.setScale( view.frame.width / backgroundNode.size.width)
        backgroundNode.anchorPoint = CGPoint(x: 0.5,y: 0.5)
        //        backgroundNode.alpha = 0.5
        addChild(backgroundNode)
    }
    func setGi(){
        gi.position = CGPoint(x: groundPoint[0] - 50, y: groundPoint[1])
        //        gi.normalTexture = gi.texture
        let gi_r = CGFloat(0.28)
        gi.size = CGSize(width: gi.size.width * gi_r, height: gi.size.height * gi_r)
        addChild(gi)
        let walk = SKAction.group([giActions[0], SKAction.moveTo(x: CGFloat(groundPoint[0]), duration: 1.6)])
        gi.run(walk)
    }
//    func moveForword(step:Int){
//        let scaleAction = SKAction.run {
//            if step < 0{
//                self.gi.xScale = abs(self.gi.xScale) * -1.0
//            }else{
//                self.gi.xScale = abs(self.gi.xScale) *  1.0
//            }
//        }
//        steps += step
//        let s = step * 9
//        let t = Double(s) / 30
//        var targetX = CGFloat(steps * 9) + gi.position.x
//        if targetX < 0{
//            targetX = 0
//        }else if targetX > size.width{
//            targetX = size.width
//        }
//        let moveAction = SKAction.moveTo(x: targetX, duration: abs(t))
//        runSequence.append(contentsOf: [scaleAction, moveAction])
//    }
    func moveForword(step:Int){
        let walkAction = SKAction.run {
            if step < 0{
                self.gi.xScale = abs(self.gi.xScale) * -1.0
            }else{
                self.gi.xScale = abs(self.gi.xScale) *  1.0
            }
            self.gi.removeAction(forKey: "walking")
            self.gi.run(SKAction.repeatForever(self.giActions[0]), withKey: "walking")
        }
        let distance = CGFloat(step) * 9
        let duration = Double(distance / 30.0)
        let moveAction = SKAction.move(by: .init(dx: distance, dy: 0), duration: duration)
        runSequence.append(contentsOf: [walkAction, moveAction])
    }
    func fillUp(color:UIColor){
        let removeWalkAction = SKAction.run {
            self.gi.removeAction(forKey: "walking")
        }
        let fillupEmitter = SKAction.run {
            guard  let emitterToAdd = self.emitter.copy() as? SKEmitterNode else {
                return
            }
            emitterToAdd.particleColor = color
            emitterToAdd.position = CGPoint(x: 20, y: 50)
            self.gi.addChild(emitterToAdd)
            
        }
        let changeColor = SKAction.run {
            
            for i in self.rects{
                let d = abs(i.position.x - self.gi.position.x - 10)
                if d < 20{
                    i.fillColor = color
                }
            }
        }
        
        let emitterAction = SKAction.sequence([removeWalkAction, SKAction.wait(forDuration: 1), fillupEmitter, SKAction.wait(forDuration: 0.7), changeColor])
        
        let group = SKAction.group([giActions[1], emitterAction])
        
        runSequence.append(contentsOf: [group])
    }
    func runCode(){
        if timer != nil{
            return
        }
        //gi.run(SKAction.repeatForever(giActions[0]))
        if isRun == true{
            return
        }
        isRun = true
        self.reset()
        let end = SKAction.run {
            self.runSequence.removeAll()
            self.isRun = false
            self.gi.removeAllActions()
            self.gi.texture = self.gi.normalTexture
            self.steps = 0
            self.checkEnd()
        }
        runSequence.append(end)
        gi.run(SKAction.sequence(runSequence))
    }
    func reset(){
        self.gi.xScale = abs(self.gi.xScale) * 1.0
        self.gi.position = CGPoint(x: groundPoint[0], y: groundPoint[1])
        for i in rects{
            i.fillColor = .white
        }
    }
    func checkEnd(){
        for i in rects{
            let c = UIColor(red: 1, green: 1, blue: 1, alpha: 1)
            if i.fillColor.isEqual(c){
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["all rect have to be full up"], solution: """
                    moveForward(step: 7)\n
                    fillUp(color: .red)\n
                    moveForward(step: 7)\n
                    fillUp(color: .yellow)\n
                    moveForward(step: 7)\n
                    fillUp(color: .blue)\n
                    moveForward(step: 7)\n
                    fillUp(color: .gray)
                    """)
//                self.gi.xScale = abs(self.gi.xScale) * 1.0
//                self.gi.position = CGPoint(x: groundPoint[0], y: groundPoint[1])
                return
            }
        }
        self.gi.position.x += 10
        self.gi.xScale = abs(self.gi.xScale) * -1.0
        self.gi.texture = self.gi.normalTexture
        
        
        backgroundColor = #colorLiteral(red: 0.1600655019, green: 0.1644849479, blue: 0.1861892343, alpha: 1)
        backgroundNode.run(SKAction.repeatForever(fireworkSound))
        emitter.alpha = 1
        
        timer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true, block: {_ in
            self.randomEmitter()
        })
        PlaygroundPage.current.assessmentStatus = .pass(message: "**🎆 Congratulations !** 🎇 [Next Page](@next)")
    }
    func randomEmitter(){
        emitter.setScale(CGFloat.random(in: 0.1...0.5))
        addEmitter(node: self, delay: Double.random(in: 0.5...2), pos: CGPoint(x: CGFloat.random(in: 20...size.width-20), y: CGFloat.random(in: 50...size.height-50)), color: UIColor.init(red: CGFloat.random(in: 0...1), green: CGFloat.random(in: 0...1), blue: CGFloat.random(in: 0...1), alpha: CGFloat.random(in: 0.5...1)))
        addEmitter(node: self, delay: Double.random(in: 0.5...2), pos: CGPoint(x: CGFloat.random(in: 20...size.width-20), y: CGFloat.random(in: 50...size.height-50)), color: UIColor.init(red: CGFloat.random(in: 0...1), green: CGFloat.random(in: 0...1), blue: CGFloat.random(in: 0...1), alpha: CGFloat.random(in: 0.5...1)))
        
    }
}

