//
//  p4GameScene.swift
//  Book_Sources
//
//  Created by 劉祐炘 on 2020/2/16.
//

import Foundation
import SpriteKit
import PlaygroundSupport


class p4GameScene: GameScene,SKPhysicsContactDelegate {
    var temple:SKSpriteNode!
    var templeRect:SKShapeNode!
    let rectColors = [#colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1), #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1), #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)]
    let rectColorAnti = [#colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1), #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1), #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1)]
    var targetIndex = 0
    var rects:[SKSpriteNode] = []
    var count = 0;
    override init() {
        super.init()
        backgroundColor = #colorLiteral(red: 0.2586915493, green: 0.2476993203, blue: 0.3753707111, alpha: 1)
        
//        backgroundColor = yoznColor
        setBackGround()
        setGi()
        setRect()
        templeChange(color: rectColors[targetIndex], t:0.6)
//        let ac = SKAction.run {
//            self.runEndAction()
//        }
//        run(SKAction.sequence([SKAction.wait(forDuration: 4), ac]))
        //
        //
        
    }
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        physicsWorld.contactDelegate = self
    }
    func didBegin(_ contact: SKPhysicsContact) {
        print(123)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("p4GameScene init error")
    }
    func reset(){
        targetIndex = 0
        temple.color = rectColors[targetIndex]
        for (index,rect) in rects.enumerated(){
            rect.color = rectColors[index]
        }
        
    }
    func runCode(){
        if isRun == true{
            return
        }
        isRun = true
        reset()
        runSequence.append(SKAction.run {
            self.isRun = false
            self.runSequence.removeAll()
            if self.targetIndex != 5{
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["check anti color and remember to use if in for"], solution:
                """
                for i in 1 ... 5{\n
                        if templeColor ==  {\n
                            fillUp(color: )\n
                        }else if templeColor == {\n
                            fillUp(color: )\n
                        }
                        else if templeColor == {\n
                            fillUp(color: )\n
                        }
                        else if templeColor == {\n
                            fillUp(color: )\n
                        }else if templeColor == {\n
                            fillUp(color: )\n
                        }\n
                        RectPower()\n
                }
                """)
            }else{
                self.targetIndex = 0
            }
        })
        gi.run(SKAction.sequence(runSequence))
        
        
        
    }
    func setBackGround(){
        var templeFrames:[SKTexture] = []
        for i in 1 ... 4{
            let f = SKTexture(imageNamed: "temple\(i).png")
            templeFrames.append(f)
        }
        
        temple = SKSpriteNode(texture: templeFrames[0])
        temple.position = CGPoint(x: frame.midX, y: frame.midY + 100)
        temple.setScale(0.4)
        temple.colorBlendFactor = 1
        temple.color = .white
        addChild(temple)
        
        let floor = SKShapeNode(rectOf: .init(width: temple.size.width, height: 2))
        floor.position = CGPoint(x: frame.midX, y: frame.midY - 44)
        floor.fillColor = .clear
        floor.strokeColor = .clear
        floor.physicsBody = .init(rectangleOf: floor.frame.size)
        floor.physicsBody?.isDynamic = false
        floor.physicsBody?.categoryBitMask = 0b0010
        floor.physicsBody?.collisionBitMask = 0b0000
        floor.physicsBody?.contactTestBitMask = 0
        addChild(floor)
        
        //        let templebk = temple.copy() as! SKSpriteNode
        //
        //        addChild(templebk)
        //        let templeMask = SKCropNode()
        //        let mask = temple.copy() as! SKSpriteNode
        //        mask.size = .init(width: mask.frame.width * 0.85, height: mask.frame.height)
        //        templeMask.maskNode = mask
        //        templeMask.addChild(temple)
        //        addChild(templeMask)
        
        let action = SKAction.animate(with: templeFrames, timePerFrame: 0.25)
        temple.run(SKAction.repeatForever(action))
        
    }
    func templeChange(color:UIColor, t:Double){
        let changeColor = SKAction.run {
           
            self.temple.color = color
            self.templeRect.fillColor = color
            //self.setPageTempleColor()//send to page 
            
        }
        let fade0 = SKAction.fadeAlpha(to: 0.35, duration: t)
        let fade1 = SKAction.fadeAlpha(to: 1, duration: t * 1.5)
        let sequence = SKAction.sequence([fade0, fade1, fade0, fade1, fade0, changeColor, fade1])
        temple.run(sequence)
    }
    func addRect(s:Double, t:Double, color:UIColor, size:Int, pos:CGPoint) -> SKSpriteNode{
        let rad = toRadians(angle: 18)
        let px = cos(rad) * -s + Double(pos.x)
        let py = sin(rad) * s + Double(pos.y)
        
        let rectimg = SKSpriteNode(imageNamed: "rect.png")
        rectimg.size = .init(width: size, height: size)
        rectimg.colorBlendFactor = 1
        rectimg.color = color
        rectimg.position = CGPoint(x: px, y: py)
        rectimg.alpha = 0
        addChild(rectimg)
        
        rectimg.physicsBody = .init(rectangleOf: rectimg.frame.size)
        rectimg.physicsBody?.isDynamic = false
        rectimg.physicsBody?.categoryBitMask = 0b0001
        rectimg.physicsBody?.collisionBitMask = 0b0010
        rectimg.physicsBody?.contactTestBitMask = 1
        
        //        let rect = SKShapeNode(rectOf: CGSize(width: size, height: size))
        //        rect.fillColor = color
        //        rect.strokeColor = .clear
        //        rect.position = CGPoint(x: px, y: py)
        //        rect.alpha = 0
        //        addChild(rect)
        
        let moveAction = SKAction.sequence([
            SKAction.move(by: .init(dx: s * cos(rad * 2), dy: s * sin(rad * 2)), duration: t),
            SKAction.move(by: .init(dx: s * cos(rad * 2), dy: s * -sin(rad * 2)), duration: t),
            SKAction.move(by: .init(dx: s * -cos(rad * 4), dy: s * -sin(rad * 4)), duration: t),
            SKAction.move(by: .init(dx: -s, dy: 0), duration: t),
            SKAction.move(by: .init(dx: s * -cos(rad * 4), dy: s * sin(rad * 4)), duration: t),
        ])
        let rotateAction = SKAction.rotate(byAngle: 5, duration: 5*t)
        let fadeAction = SKAction.sequence([
            SKAction.fadeAlpha(to: 0.5, duration: t / 2),
            SKAction.fadeAlpha(to: 1, duration: t / 2)
        ])
        let group = SKAction.group([moveAction, rotateAction])
        
        let repeatAction1 = SKAction.repeatForever(group)
        let repeatAction2 = SKAction.repeatForever(fadeAction)
        
        //        rect.run(SKAction.group([SKAction.fadeIn(withDuration: 1.5), repeatAction1, repeatAction2]))
        rectimg.run(SKAction.group([SKAction.fadeIn(withDuration: 1.5), repeatAction1, repeatAction2]))
        
        
        return rectimg
    }
    func setGi(){
        gi.position = CGPoint(x: -20, y: 200)
        let gi_r = CGFloat(0.35)
        gi.size = CGSize(width: gi.size.width * gi_r, height: gi.size.height * gi_r)
        let moveAction = SKAction.moveTo(x: 20, duration: 1.7)
        let group = SKAction.group([giActions[0], moveAction])
        let endAction = SKAction.run {
            self.gi.removeAllActions()
        }
        gi.run(SKAction.sequence([group]))
        addChild(gi)
        
    }
    func setRect(){
        let addAction = SKAction.run {
            
            let r = self.addRect(s: 80, t: 1.6, color: self.rectColors[self.count], size: 28, pos: .init(x: self.temple.frame.midX + 14, y: self.temple.frame.midY - 23))
            self.count += 1
            self.rects.append(r)
        }
        run(SKAction.repeat(SKAction.sequence([addAction, SKAction.wait(forDuration: 1.6)]), count: 5))
        
        let rect = SKShapeNode(rectOf: .init(width: 10, height: 10))
        
        rect.fillColor = .white
        rect.position = .init(x: self.temple.frame.midX + 4, y: self.temple.frame.midY - 23)
        rect.zRotation = 0.71
        rect.alpha = 0
        addChild(rect)
        let fadeAction = SKAction.sequence([
            SKAction.fadeAlpha(to: 1, duration: 1.5),
            SKAction.fadeAlpha(to: 0.5, duration: 1.5)
        ])
        rect.run(SKAction.repeatForever(fadeAction))
        templeRect = rect
    }
    func fillup(color:UIColor){
        let addRectAction = SKAction.sequence([
            SKAction.wait(forDuration: 1.1),
            SKAction.run {
                self.emitter.setScale(0.35)
                self.addEmitter(node: self.gi, delay: 1, pos: CGPoint(x: 37, y: 55), color: color)
            },
            SKAction.run {
                if let r = self.gi.childNode(withName: "rect"){
                    r.removeFromParent()
                }
                let rect = SKSpriteNode(imageNamed: "rect.png")
                rect.size = .init(width: 27, height: 27)
                rect.position = CGPoint(x: 35, y: 45)
                rect.alpha = 0
                rect.name = "rect"
                rect.colorBlendFactor = 1
                rect.color = color
                rect.run(self.RotatefloatAction(node: rect))
                rect.zPosition = 1
                self.gi.addChild(rect)
                rect.run(SKAction.fadeAlpha(to: 1, duration: 0.5))
            }
        ])
        let group = SKAction.group([giActions[1], addRectAction])
        runSequence.append(group)
    }
    func RectPower(){
        let prepareAction = SKAction.run {
            guard let rect = self.gi.childNode(withName: "rect") as? SKSpriteNode else {return}
            let moveDown = SKAction.move(by: CGVector(dx: 0, dy: -30), duration: 0.8)
            let rDown = SKAction.rotate(byAngle: 0.5, duration: 0.8)
            let groupDown = SKAction.group([moveDown, rDown])
            
            let moveUp = SKAction.move(by: CGVector(dx: 135, dy: 100), duration: 2.4)
            let rUp = SKAction.rotate(byAngle: 0.5, duration: 2.4)
            let groupUp = SKAction.group([moveUp, rUp])
            
            let end = SKAction.run {
                //self.addEmitter(node: rect, delay: 1, pos: .zero, color: rect.color)
                rect.run(SKAction.fadeAlpha(to: 0, duration: 0.5))
            }
            let rectAction = SKAction.sequence([
                groupDown,
                groupUp,
                end
            ])
            rect.run(rectAction)
        }
        let catchAction = SKAction.run {
            self.templeCheck()
        }
        let group = SKAction.group([giActions[2], prepareAction, catchAction])
        runSequence.append(group)
        runSequence.append(SKAction.wait(forDuration: 2.5))
        runSequence.append(SKAction.run {
            self.gi.texture = self.gi.normalTexture
        })
    }
    func rectRemove(index:Int){
        let rect = rects[index]
        let changeColor = SKAction.run {
            rect.color = .darkGray
        }
        let wait = SKAction.wait(forDuration: 1)
        let fade0 = SKAction.fadeAlpha(to: 0.35, duration: 1.5)
        let fade1 = SKAction.fadeAlpha(to: 1, duration: 0.8)
        rect.run(SKAction.sequence([wait, fade0, changeColor, fade1]))
    }
    func templeCheck(){
        guard let rect = self.gi.childNode(withName: "rect") as? SKSpriteNode else {return}
        var runActions = [SKAction.wait(forDuration: 3)]
        let checkAction = SKAction.run {
            
            if rect.color.isEqual(self.rectColorAnti[self.targetIndex]){
                self.rectRemove(index: self.targetIndex)
                self.targetIndex += 1
                self.temple.color = .white
                self.emitter.setScale(1)
                self.addEmitter(node: rect, delay: 1, pos: .init(x: 0, y: 0), color: .white)
                self.templeRect.fillColor = .white
                if self.targetIndex == 5{
//                    self.targetIndex = 0
                    self.runEndAction()
                    self.templeChange(color: .white, t: 0.35)
                    PlaygroundPage.current.assessmentStatus = .pass(message: "**Perfect!** The temple is going to recover.\n you have completed all the challenges!\n Thank you.")
                }else{
                    self.templeChange(color: self.rectColors[self.targetIndex], t: 0.35)
                }
                
                
            }else{
                self.emitter.setScale(1)
                self.addEmitter(node: rect, delay: 1, pos: .init(x: 0, y: 0), color: .black)
                
            }
            
        }
        runActions.append(checkAction)
        temple.run(SKAction.sequence(runActions))
    }
    func runEndAction(){
        let ac = SKAction.run {
            for i in self.rects{
                i.removeAllActions()
                i.physicsBody?.isDynamic = true
            }
        }
        run(SKAction.sequence([SKAction.wait(forDuration: 2.5), ac]))
        
    }
    
}
