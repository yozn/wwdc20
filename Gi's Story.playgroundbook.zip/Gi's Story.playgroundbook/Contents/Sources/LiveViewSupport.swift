//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import PlaygroundSupport
/// Instantiates a new instance of a live view.
///
/// By default, this loads an instance of `LiveViewController` from `LiveView.storyboard`.

public func instantiateLiveView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "LiveView", bundle: nil)
    
    guard let viewController = storyboard.instantiateInitialViewController() else {
        fatalError("LiveView.storyboard does not have an initial scene; please set one or update this function")
    }
    
    guard let liveViewController = viewController as? LiveViewController else {
        fatalError("LiveView.storyboard's initial scene is not a LiveViewController; please either update the storyboard or this function")
    }
    
    return liveViewController
}
public func getGameViewController(pageName:String) -> PlaygroundLiveViewable{
    
    switch pageName{
    case "p2":
        return GameViewController(scene: p2GameScene(), name: "p2")
    case "p3":
        return GameViewController(scene: p3GameScene(), name: "p3")
    case "p4":
        return GameViewController(scene: p4GameScene(), name: "p4")
    default:
        return GameViewController(scene: GameScene(), name: "p2")
    }
}

public func sendToView(_ value: PlaygroundValue) {
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(value)
}
public func RectPower(dx:Double, dy:Double){
    let dict = ["dx":PlaygroundValue.floatingPoint(dx),
                "dy":PlaygroundValue.floatingPoint(dy)]
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(.dictionary(dict))
}
public func RectPower(){
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(.string("RectPower"))
}
public func moveForward(step:Int){
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(.integer(step))
}
public func fillUp(color:UIColor){
    var arr:[PlaygroundValue] = []
    arr.append(.floatingPoint(Double(color.rgba.red)))
    arr.append(.floatingPoint(Double(color.rgba.green)))
    arr.append(.floatingPoint(Double(color.rgba.blue)))
    arr.append(.floatingPoint(Double(color.rgba.alpha)))
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(.array(arr))
}

public func ValueArrToUIColor(value:[PlaygroundValue]) -> UIColor{
    var arr:[CGFloat] = [1 , 1,  1, 1]
    for (index,i) in value.enumerated(){
        switch i {
        case .floatingPoint(let data):
            arr[index] = CGFloat(data)
        default:
            break
        }
    }
    
    return UIColor(red: arr[0], green: arr[1], blue: arr[2], alpha: arr[3])
}
extension PlaygroundValue{
    
    func cgfloatFromDict(withKey:String) -> CGFloat?{
        if case .dictionary(let dict) = self,
            let value = dict[withKey],
            case .floatingPoint(let num) = value {
            return CGFloat(num)
        }
        return nil
    }
    func runNameFromDict(withKey:String) -> String?{
        if case .dictionary(let dict) = self,
            let value = dict[withKey],
            case .string(let name) = value{
            return String(name)
        }
        return nil
    }
}
extension UIColor {
    public var rgba: (red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat) {
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        return (red, green, blue, alpha)
    }
}

